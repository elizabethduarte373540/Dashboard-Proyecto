import streamlit as st
import pandas as pd
def Ramon_junto():
    image = "C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/adq.png"
    st.image(image, use_container_width=True)
    df = pd.read_csv("C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Instagram.csv")
    inversion = df["Total_inversion"]
    adq = df["adquisiciones"]
    Costo_adquisición = inversion / adq
    Costo_adquisición= Costo_adquisición.mean()
    st.write(f"Costo por adquisición: {Costo_adquisición}")
    try:
        with open('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Ramon.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
Ramon_junto()

