import streamlit as st
from Moises import moises_junto
from Loya import loya_junto
from Hector import Hector_junto
from Eduardo import Eduardo_junto

st.markdown("<h1 style='text-align: center; color: #FFB6C1;'>Crecimiento Digital</h1>", unsafe_allow_html=True)

models = {
    "Tasa de viralidad ":Eduardo_junto,
    "Tasa de crecimiento de canal digital":Hector_junto,
    "Ventas por canal ":loya_junto,
    "Rotación de nuevos modelos":moises_junto,
}
selected_model = st.selectbox('Elige un Kpis:', list(models.keys()))
result = models[selected_model]()
st.write(result)
