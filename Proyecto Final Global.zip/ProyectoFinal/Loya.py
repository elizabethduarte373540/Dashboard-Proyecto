import streamlit as st
import pandas as pd
def loya_junto():

    def ventas_canal(datos, total_real):
        datos['Porcentaje (%)'] = ((datos['Ganancias'] / total_real) * 100).round(2)
        return datos[['Canal', 'Ganancias', 'Porcentaje (%)']]

    # Datos iniciales
    datos_ventas = pd.DataFrame({
        'Canal': ['Instagram', 'Ventas fuera de redes sociales'],
        'Ganancias': [1107, 4380]
    })

    # Total de ganancias reales
    total_ganancias_reales = 5487

    # Calcular resultados
    resultado = ventas_canal(datos_ventas, total_ganancias_reales)

    # Mostrar resultados
    st.write(resultado)
loya_junto()