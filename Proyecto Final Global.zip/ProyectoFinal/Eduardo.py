import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

def Eduardo_junto():
    try:
        data = pd.read_csv('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Eduardo.csv')
    except FileNotFoundError:
        st.error(
            "El archivo 'BD fetch FB.csv' no fue encontrado. Asegúrate de colocarlo en el mismo directorio que este script.")
        return

    # Verificar que existan las columnas en la BD
    if "Veces que se compartió" not in data.columns or "Alcance" not in data.columns:
        st.error("Las columnas necesarias ('Veces que se compartió' y 'Alcance') no se encuentran en el archivo.")
        return

    # Mostrar unicamente las tablas de los datos recaudados para el procedimiento
    st.subheader("Datos relevantes:")
    st.write(data[["Alcance", "Veces que se compartió"]])

    # Conversion de las tablas a valor numericos, para no contar otro tipo de valores.
    data["Veces que se compartió"] = pd.to_numeric(data["Veces que se compartió"], errors='coerce').fillna(0)
    data["Alcance"] = pd.to_numeric(data["Alcance"], errors='coerce').fillna(0)

    total_compartidos = data["Veces que se compartió"].sum()
    total_alcance = data["Alcance"].sum()

    # Calculo de la tasa de viralidad
    if total_alcance > 0:
        tasa_viralidad = (total_compartidos / total_alcance) * 100
    else:
        tasa_viralidad = 0

    # Resultados
    st.write(f"Alcance total: {total_alcance}")
    st.write(f"Veces que se compartió: {total_compartidos}")
    st.write(f"Tasa de viralidad: {tasa_viralidad:.2f}%")

    # Creacion del grafico con los resultados
    fig, ax = plt.subplots()
    data_aggregated = data[["Alcance", "Veces que se compartió"]].sum()
    data_aggregated.plot(kind="bar", color=["skyblue", "orange"], ax=ax)

    # Añadir indicadores al grafico
    ax.set_title("Alcance vs Veces que se compartió")
    ax.set_ylabel("Cantidad")
    ax.set_xticklabels(["Alcance", "Veces que se compartió"], rotation=0)

    st.pyplot(fig)
    # Interpretación en formato de tabla
    st.subheader("Interpretación de los Resultados del KPI")
    interpretacion = pd.DataFrame({
        "Tasa de Viralidad (%)": ["Alta (> 5%)", "Moderada (2-5%)", "Baja (< 2%)"],
        "Interpretación": [
            "El contenido tiene una gran viralidad, generando un impacto significativo y siendo ampliamente compartido.",
            "El contenido tiene una viralidad moderada, lo que indica que fue compartido por un segmento considerable de la audiencia.",
            "El contenido tiene una baja viralidad, indicando que necesita optimización o promoción para alcanzar una mayor difusión."
        ]
    })
    st.table(interpretacion)
Eduardo_junto()