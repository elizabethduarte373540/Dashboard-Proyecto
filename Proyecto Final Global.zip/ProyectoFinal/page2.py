import streamlit as st

from Luis import luis_junto
from Gorge import Gorge_junto
from Ramon import Ramon_junto

st.markdown("<h1 style='text-align: center; color: #FFB6C1;'>Mejora en Publicidad</h1>", unsafe_allow_html=True)

models = {
    "Costo por adquisición":Ramon_junto,
    "Costo por click":Gorge_junto,
    "Sentimiento":luis_junto,
}
selected_model = st.selectbox('Elige un Kpis:', list(models.keys()))
result = models[selected_model]()
st.write(result)