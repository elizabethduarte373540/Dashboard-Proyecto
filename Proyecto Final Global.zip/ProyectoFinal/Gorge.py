import streamlit as st
import pandas as pd
def Gorge_junto():
    image = "C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/click.png"
    st.image(image, use_container_width=True)
    df = pd.read_csv("C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Instagram.csv")
    inversion = df["Total_inversion"]
    clics = df["Clics "]
    costo_por_click = inversion / clics
    promedio_costo_por_click = costo_por_click.mean()
    st.write(f"El costo por clic es:$ {promedio_costo_por_click:.2f}")
    try:
        # Intentamos abrir el archivo en modo lectura
        with open('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/Gorge.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()  # Leemos el contenido del archivo
        return contenido  # Devolvemos el contenido del archivo
    except FileNotFoundError:
        return "El archivo no se encontró."  # Si el archivo no existe, mostramos un mensaje de error
    except Exception as e:
        return f"Ocurrió un error: {e}"
Gorge_junto()


