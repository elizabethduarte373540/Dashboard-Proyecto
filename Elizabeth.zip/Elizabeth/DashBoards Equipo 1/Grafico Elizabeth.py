def elizabeth_junto():
    import pandas as pd
    import matplotlib.pyplot as plt

    # Cargar los datos
    data = pd.read_csv('files/datos pagina web fetch - Informe de tráfico_2023-11-13-2.csv')

    # Limpiar y preparar los datos
    # Asegurarse de que la columna 'Tasa de rebote' sea de tipo string
    data['Tasa de rebote'] = data['Tasa de rebote'].astype(str).str.replace('%', '', regex=False)
    data['Tasa de rebote'] = pd.to_numeric(data['Tasa de rebote'], errors='coerce')
    data['Total de visitas de pagina'] = pd.to_numeric(data['Total de visitas de pagina'], errors='coerce')
    data['Fecha'] = pd.to_datetime(data['Fecha'], errors='coerce')

    # Eliminar filas con datos faltantes
    cleaned_data = data.dropna(subset=['Tasa de rebote', 'Total de visitas de pagina', 'Fecha'])

    # Calcular la tasa de rebote (KPI)
    total_rebotes = cleaned_data['Tasa de rebote'].sum()
    total_visitas = cleaned_data['Total de visitas de pagina'].sum()
    kpi_tasa_rebote = (total_rebotes / total_visitas) * 100 if total_visitas > 0 else None

    print(f"KPI Tasa de Rebote: {kpi_tasa_rebote:.2f}%")

    # Ordenar por fecha para un gráfico claro
    cleaned_data = cleaned_data.sort_values(by='Fecha')

    # Crear un gráfico de líneas para visualizar la Tasa de Rebote
    plt.figure(figsize=(12, 6))
    plt.plot(cleaned_data['Fecha'], cleaned_data['Tasa de rebote'], marker='o', color='blue', label='Tasa de Rebote')

    # Configuración del gráfico
    plt.title('Tasa de Rebote por Fecha', fontsize=16)
    plt.xlabel('Fecha', fontsize=12)
    plt.ylabel('Tasa de Rebote (%)', fontsize=12)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.xticks(rotation=45, fontsize=10)
    plt.ylim(0, 100)  # Asegurarse de que el eje y esté entre 0 y 100
    plt.legend()

    plt.tight_layout()
    plt.show()

elizabeth_junto()