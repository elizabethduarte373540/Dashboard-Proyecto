import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import os

# Define la ruta base para los archivos
BASE_PATH = r"C:\Users\danny\PycharmProjectsBr\Unidad4\files"

def elizabeth_junto():
    st.header("Análisis: Elizabeth")
    try:
        # Leer y procesar datos del archivo CSV
        csv_path = os.path.join(BASE_PATH, 'datos pagina web fetch - Informe de tráfico_2023-11-13-2.csv')
        data = pd.read_csv(csv_path)

        # Limpiar y preparar los datos
        data['Tasa de rebote'] = pd.to_numeric(data['Tasa de rebote'].str.replace('%', ''), errors='coerce')
        data['Total de visitas de pagina'] = pd.to_numeric(data['Total de visitas de pagina'], errors='coerce')

        # Eliminar filas con datos faltantes necesarios para el cálculo
        cleaned_data = data.dropna(subset=['Tasa de rebote', 'Total de visitas de pagina'])

        # Calcular KPI
        total_rebotes = cleaned_data['Tasa de rebote'].sum()
        total_visitas = cleaned_data['Total de visitas de pagina'].sum()
        kpi_tasa_rebote = (total_rebotes / total_visitas) * 100 if total_visitas > 0 else None

        if kpi_tasa_rebote is not None:
            st.metric("KPI Tasa de Rebote", f"{kpi_tasa_rebote:.2f}%")
        else:
            st.warning("No se pudo calcular la tasa de rebote. Faltan datos.")

        # Mostrar contenido del archivo .txt
        txt_path = os.path.join(BASE_PATH, 'elizabeth.txt')
        with open(txt_path, 'r', encoding='utf-8') as file:
            st.text(file.read())
    except FileNotFoundError as e:
        st.error(f"Archivo no encontrado: {e}")
    except Exception as e:
        st.error(f"Ocurrió un error: {str(e)}")

def karen_junto():
    st.header("Análisis: Karen")
    try:
        # Leer datos del archivo CSV
        csv_path = os.path.join(BASE_PATH, 'Pagina_Web.csv')
        df = pd.read_csv(csv_path)
        visitantes = df['Visitantes_Unicos'].sum()
        cliqueado = df['WhatsApp_cliqueado'].sum()

        # Calcular KPI
        if visitantes != 0:
            conversion = (cliqueado / visitantes) * 100
            st.metric("Tasa de Conversión", f"{conversion:.2f}%")
        else:
            st.warning("No se puede calcular el porcentaje, ya que el número de visitantes es 0.")

        # Mostrar contenido del archivo .txt
        txt_path = os.path.join(BASE_PATH, 'Karen.txt')
        with open(txt_path, 'r', encoding='utf-8') as file:
            st.text(file.read())

        # Gráfico de dispersión
        plt.figure(figsize=(10, 6))
        plt.scatter(df['WhatsApp_cliqueado'], df['Visitantes_Unicos'], color='blue', alpha=0.5)
        plt.title('Relación entre WhatsApp cliqueado y Visitantes Unicos', fontsize=14)
        plt.xlabel('WhatsApp cliqueado', fontsize=12)
        plt.ylabel('Visitantes Unicos', fontsize=12)
        st.pyplot(plt)
    except FileNotFoundError as e:
        st.error(f"Archivo no encontrado: {e}")
    except Exception as e:
        st.error(f"Ocurrió un error: {str(e)}")

def evelyn_junto():
    st.header("Análisis: Evelyn")
    try:
        # Leer datos del archivo CSV
        csv_path = os.path.join(BASE_PATH, 'Pagina_Web.csv')
        df = pd.read_csv(csv_path)
        df = df.dropna(subset=['Tiempo_en_segundos', 'Visitantes_Unicos'])

        # Calcular KPI
        total_tiempo = df['Tiempo_en_segundos'].sum()
        visitantes = df['Visitantes_Unicos'].sum()

        if total_tiempo != 0:
            tiempo_usuario = (total_tiempo / visitantes) if visitantes > 0 else None
            st.metric("Tiempo en la Página por Usuario", f"{tiempo_usuario:.2f} segundos")
        else:
            st.warning("No se puede calcular el tiempo promedio, ya que el tiempo total es 0.")

        # Mostrar contenido del archivo .txt
        txt_path = os.path.join(BASE_PATH, 'Evelyn.txt')
        with open(txt_path, 'r', encoding='utf-8') as file:
            st.text(file.read())

        # Gráfico de dispersión
        plt.figure(figsize=(10, 6))
        plt.scatter(df['Tiempo_en_segundos'], df['Visitantes_Unicos'], color='blue', alpha=0.5)
        plt.title('Relación entre Tiempo en Segundos y Visitantes Unicos', fontsize=14)
        plt.xlabel('Tiempo en Segundos', fontsize=12)
        plt.ylabel('Visitantes Unicos', fontsize=12)
        st.pyplot(plt)
    except FileNotFoundError as e:
        st.error(f"Archivo no encontrado: {e}")
    except Exception as e:
        st.error(f"Ocurrió un error: {str(e)}")

# Crear el menú del dashboard
st.sidebar.title("Menú")
opcion = st.sidebar.selectbox("Selecciona un análisis:", ["Elizabeth", "Karen", "Evelyn"])

# Mostrar la función correspondiente
if opcion == "Elizabeth":
    elizabeth_junto()
elif opcion == "Karen":
    karen_junto()
elif opcion == "Evelyn":
    evelyn_junto()
