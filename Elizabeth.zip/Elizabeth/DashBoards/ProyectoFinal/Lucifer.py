import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st

def calcular_tasa_retencion(df):
    table = df[['Duración (segundos)', 'Segundos en promedio reproducidos']]
    table = table.dropna()
    table['Tasa de retencion de video %'] = (table['Segundos en promedio reproducidos'] / table['Duración (segundos)']) * 100
    return table
def denisse_junto():
    st.title('Análisis de Tasa de Retención de Video')

    df = pd.read_csv('ProyectoFinal/denisse.csv')
    table = calcular_tasa_retencion(df)

    st.subheader("Datos de Retención de Video")
    st.write(table[['Duración (segundos)', 'Segundos en promedio reproducidos', 'Tasa de retencion de video %']])

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.bar(table.index, table['Tasa de retencion de video %'], color='skyblue')
    ax.set_xlabel('Videos')
    ax.set_ylabel('Tasa de Retención de Video (%)')
    ax.set_title('Tasa de Retención de Video por Video')
    st.pyplot(fig)
    try:
        with open('ProyectoFinal/Denisse.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"

denisse_junto()
