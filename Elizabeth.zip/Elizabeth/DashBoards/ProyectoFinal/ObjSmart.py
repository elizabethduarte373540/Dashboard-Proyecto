import streamlit as st

def E1():
    try:
        with open('ProyectoFinal/E1.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
def E2():
    try:
        with open('ProyectoFinal/E2.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
def E3():
    try:
        with open('ProyectoFinal/E3.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
def E4():
    try:
        with open('ProyectoFinal/E4.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"

models = {
    "Mejora de Conversión Web": E1(),
    "Mejora en Publicidad": E2(),
    "Crecimiento Digital": E3(),
    "Optimización Publicitaria": E4()
}
selected_model = st.selectbox('Elige un Objetivo :', list(models.keys()))
st.write(models[selected_model])