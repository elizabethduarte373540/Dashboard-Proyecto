import streamlit as st

col2, col1, col3 = st.columns(3)

with col1:
    image = "ProyectoFinal/fetch.jpg"
    st.image(image, use_container_width=True)

with col2:
    try:
        with open('ProyectoFinal/inicio.txt', 'r', encoding='utf-8') as archivo:
            contenido = archivo.read()
        st.write(contenido)  # Display the content of the file
    except FileNotFoundError:
        st.write("El archivo no se encontró.")  # Error if file not found
    except Exception as e:
        st.write(f"Ocurrió un error: {e}")  # Display other errors

with col3:
    try:
        with open('C:/Users/Luis Frausto/PycharmProjects/pythonProject/ProyectoFinal/inicio1.txt', 'r', encoding='utf-8') as archivo:
            contenido = archivo.read()
        st.write(contenido)  # Display the content of the file
    except FileNotFoundError:
        st.write("El archivo no se encontró.")  # Error if file not found
    except Exception as e:
        st.write(f"Ocurrió un error: {e}")  # Display other errors

