import streamlit as st
import pandas as pd
def jorge_junto():
    image = "ProyectoFinal/click.png"
    st.image(image, use_container_width=True)
    df = pd.read_csv("ProyectoFinal/Instagram.csv")
    inversion = df["Total_inversion"]
    clics = df["Clics "]
    costo_por_click = inversion / clics
    promedio_costo_por_click = costo_por_click.mean()
    st.write(f"El costo por clic es:$ {promedio_costo_por_click:.2f}")
    try:
        with open('ProyectoFinal/jorge.txt', 'r',encoding='utf-8') as archivo: contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
jorge_junto()


