import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
def diana():
    def analizar_ctr(path_csv):
        # Cargar los datos
        df = pd.read_csv(path_csv)

        # Asegurarse de que las columnas 'Clics en el enlace' y 'Impresiones' sean numéricas
        df['Clics en el enlace'] = pd.to_numeric(df['Clics en el enlace'], errors='coerce')
        df['Impresiones'] = pd.to_numeric(df['Impresiones'], errors='coerce')

        # Verificar si hay valores nulos en las columnas de Clics en el enlace o Impresiones
        if df[['Clics en el enlace', 'Impresiones']].isnull().sum().any():
            st.warning(
                "Existen valores nulos en las columnas 'Clics en el enlace' o 'Impresiones'. Estos se han convertido a NaN.")

        # Calcular el CTR: (Total de clics / Impresiones) * 100
        df['CTR_num'] = (df['Clics en el enlace'] / df[
            'Impresiones']) * 100  # columna numérica para calclular en la grafica

        # Formatear el CTR como porcentaje solo para visualización en porcentajes
        df['CTR'] = df['CTR_num'].round(2).astype(str) + '%'

        # Verificar que la columna CTR ha sido calculada correctamente
        st.write("### Datos con el CTR calculado")
        st.write(df[['Hora de publicación', 'Identificador de la publicación', 'CTR']].head())

        # Agrupar por fecha si se desea ver la evolución diaria del CTR
        df['Fecha'] = pd.to_datetime(df['Hora de publicación']).dt.date

        # Agrupar por fecha para ver la evolución del CTR (usando la columna numérica 'CTR_num' para el cálculo)
        df_grouped = df.groupby(df['Fecha'])['CTR_num'].mean().reset_index()

        # Crear una gráfica con streamlit para mostrar el CTR a lo largo del tiempo
        st.title('Análisis del CTR de publicaciones de Facebook')
        st.write(
            'Este gráfico muestra cómo ha evolucionado el CTR de las publicaciones en la Red Social Facebook a lo largo del periodo de lo meses de Septiembre, Octubre y Noviembre.')

        # Usamos la columna 'CTR_num' para los cálculos y la gráfica
        plt.figure(figsize=(10, 6))
        plt.plot(df_grouped['Fecha'], df_grouped['CTR_num'], marker='o', linestyle='-', color='b')

        # Mostrar el formato porcentual en el eje Y
        plt.title('Evolución del CTR a lo largo del tiempo')
        plt.xlabel('Fecha')
        plt.ylabel('CTR (%)')
        plt.xticks(rotation=45)
        plt.grid(True)
        st.pyplot(plt)

        # Mostrar el CTR calculado en la consola
        print(df["CTR"])

    # Llamar a la función con la ruta al archivo CSV
    analizar_ctr("ProyectoFinal/BDfb_clean.csv")

    try:
        with open('ProyectoFinal/Diana.txt', 'r',encoding='utf-8') as archivo:contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
diana()
