import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st

def Oscar_junto():
    st.title("Cálculo de CPM e Impresiones")
    st.write("Carga un archivo CSV para calcular el CPM y visualizar las impresiones y alcance por publicación.")

    uploaded_file = st.file_uploader("ProyectoFinal/Oscar.csv",type=["csv"])

    if uploaded_file:
        data = pd.read_csv(uploaded_file)
        st.write("Vista previa de los datos:")
        st.write(data.head())

        costo_total = 400
        st.write(f"El costo total de la campaña es: ${costo_total} pesos.")

        data['CPM'] = (costo_total / data['Impresiones']) * 1000

        total_impresiones = data['Impresiones'].sum()
        data['Porcentaje'] = (data['Impresiones'] / total_impresiones) * 100

        max_impresiones = data['Impresiones'].max()
        max_fila = data[data['Impresiones'] == max_impresiones].iloc[0]
        max_porcentaje = max_fila['Porcentaje']
        st.write(f"La publicación con más impresiones representa el {max_porcentaje:.2f}% del total de impresiones.")
        st.write("Detalles de la publicación con más impresiones:")
        st.write(max_fila)

        texto_explicacion = (
            f"Análisis del KPI - CPM (Costo Por Mil):\n\n"
            f"El Costo Por Mil impresiones (CPM) es un indicador clave para medir la eficiencia de la inversión publicitaria.\n"
            f"En esta campaña, el costo total fue de ${costo_total:.2f} pesos, y se alcanzaron un total de {total_impresiones} impresiones.\n"
            f"El CPM promedio fue calculado para todas las publicaciones, y la publicación con más impresiones obtuvo el {max_porcentaje:.2f}% del total.\n\n"
            f"Este análisis ayuda a identificar qué publicaciones generaron mayor impacto, facilitando la toma de decisiones "
            f"para optimizar futuras campañas y asignar mejor el presupuesto.\n"
        )

        with open("analisis_kpi.txt", "w", encoding="utf-8") as file:
            file.write(texto_explicacion)

        with open("analisis_kpi.txt", "r", encoding="utf-8") as file:
            st.download_button(
                label="Descargar análisis en archivo .txt",
                data=file.read(),
                file_name="analisis_kpi.txt",
                mime="text/plain",
            )

        st.write("Datos con el cálculo de CPM y porcentaje:")
        st.write(data[['Impresiones', 'Alcance', 'CPM', 'Porcentaje']])

        fig, ax = plt.subplots(figsize=(12, 6))
        barras = ax.bar(data.index, data['Impresiones'], color='green', alpha=0.6, label='Impresiones')

        for barra, impresiones, porcentaje in zip(barras, data['Impresiones'], data['Porcentaje']):
            ax.text(
                barra.get_x() + barra.get_width() / 2,
                barra.get_height(),
                f'{int(impresiones)}\n({porcentaje:.1f}%)',
                ha='center', va='bottom', fontsize=9, color='black'
            )

        ax.set_xlabel('Publicaciones')
        ax.set_ylabel('Cantidad de Impresiones')
        ax.set_title('Impresiones por Publicación con Porcentajes')
        ax.legend()

        st.pyplot(fig)

        csv_resultado = data.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Descargar resultados como CSV",
            data=csv_resultado,
            file_name="resultado_cpm.csv",
            mime="text/csv",
        )
Oscar_junto()