import streamlit as st

from Lucifer import denisse_junto
from Oscar import Oscar_junto
from CTR_FACEBOOK import diana

st.markdown("<h1 style='text-align: center; color: #FFB6C1;'>Optimización Publicitaria</h1>", unsafe_allow_html=True)
models = {
    "Tasa de clicks":diana,
    "Costo por mil": Oscar_junto,
    "Tasa de Repeticion De Video": denisse_junto,
}
selected_model = st.selectbox('Elige un Kpis:', list(models.keys()))
result = models[selected_model]()
st.write(result)
