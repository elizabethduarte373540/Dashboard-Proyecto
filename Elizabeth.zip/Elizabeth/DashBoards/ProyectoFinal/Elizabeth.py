import streamlit as st
import pandas as pd

def Elizabeth_junto():
    image = "ProyectoFinal/rebote.png"
    st.image(image, use_container_width=True)

    data = pd.read_csv('ProyectoFinal/Pagina_Web.csv')

    data['Tasa de rebote'] = pd.to_numeric(data['Tasa de rebote'].str.replace('%', ''), errors='coerce')
    data['Total de visitas de pagina'] = pd.to_numeric(data['Total de visitas de pagina'], errors='coerce')

    cleaned_data = data.dropna(subset=['Tasa de rebote', 'Total de visitas de pagina'])

    total_rebotes = cleaned_data['Tasa de rebote'].sum()
    total_visitas = cleaned_data['Total de visitas de pagina'].sum()

    kpi_tasa_rebote = (total_rebotes / total_visitas) * 100 if total_visitas > 0 else None

    st.write(f"KPI Tasa de Rebote: {kpi_tasa_rebote:.2f}%" if kpi_tasa_rebote is not None else "No se puede calcular el KPI debido a datos faltantes o incorrectos.")

    try:
        with open('ProyectoFinal/elizabeth.txt', 'r',
                  encoding='utf-8') as archivo:
            contenido = archivo.read()
        return contenido
    except FileNotFoundError:
        return "El archivo no se encontró."
    except Exception as e:
        return f"Ocurrió un error: {e}"
Elizabeth_junto()
